<?php
/**
 * Plugin Name: Budly Sales Agent
 * Description: Zero-cost guided sales assistant for Wake'n'Bake Lounge and CCCultivate.
 * Version: 1.0.0
 * Author: Compassionate Care Cultivators
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: budly-sales
 */

if (!defined('ABSPATH')) { exit; }

define('BUDLY_SALES_VERSION', '1.0.0');
define('BUDLY_SALES_DIR', plugin_dir_path(__FILE__));
define('BUDLY_SALES_URL', plugin_dir_url(__FILE__));

function budly_sales_activate() {
    $pages = array(
        'chat' => array('Ask Budly', '[budly_sales_agent]'),
        'policies' => array('Customer Policies', '[budly_sales_policies]'),
    );
    foreach ($pages as $key => $page) {
        $existing = get_page_by_path(sanitize_title($page[0]));
        if ($existing) {
            update_option('budly_sales_' . $key . '_page_id', $existing->ID);
            continue;
        }
        $page_id = wp_insert_post(array(
            'post_title' => $page[0],
            'post_content' => $page[1],
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
        if (!is_wp_error($page_id)) {
            update_option('budly_sales_' . $key . '_page_id', $page_id);
        }
    }
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'budly_sales_activate');

function budly_sales_enqueue() {
    wp_enqueue_style('budly-sales', BUDLY_SALES_URL . 'assets/budly-sales.css', array(), BUDLY_SALES_VERSION);
    wp_enqueue_script('budly-sales', BUDLY_SALES_URL . 'assets/budly-sales.js', array(), BUDLY_SALES_VERSION, true);
    $policy_page = get_permalink((int) get_option('budly_sales_policies_page_id'));
    wp_localize_script('budly-sales', 'BudlySalesConfig', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('budly_sales_handoff'),
        'supportEmail' => 'budlysupport@gmail.com',
        'shopUrl' => home_url('/shop/'),
        'storeApiUrl' => home_url('/wp-json/wc/store/v1/products?per_page=100'),
        'policiesUrl' => $policy_page ? $policy_page : home_url('/customer-policies/'),
    ));
}

function budly_sales_shortcode() {
    budly_sales_enqueue();
    $policy_page = get_permalink((int) get_option('budly_sales_policies_page_id'));
    ob_start(); ?>
    <div class="budly-shell" data-budly-sales>
      <aside class="budly-brand">
        <p class="budly-eyebrow">Wake'n'Bake Lounge</p>
        <h2>A calmer way to find your fit.</h2>
        <p>Meet Budly—your education-first shopping guide for wellness, culinary products, learning, memberships, and wholesale inquiries.</p>
        <div class="budly-promise">✓ <span>No pressure. No invented claims. One clear next step.</span></div>
        <a href="<?php echo esc_url(home_url('/shop/')); ?>">Browse the full shop ↗</a>
      </aside>
      <section class="budly-chat" aria-label="Chat with Budly">
        <header><span class="budly-avatar">B</span><span><strong>Budly Sales</strong><small>● Ready to help</small></span><button type="button" data-budly-restart hidden>Start over</button></header>
        <div class="budly-messages" data-budly-messages aria-live="polite"></div>
        <form class="budly-composer" data-budly-form><div data-budly-fields></div><button type="submit" data-budly-send>Continue</button></form>
        <p class="budly-fine">For adults. Product information only—not medical or legal advice. <a href="<?php echo esc_url($policy_page ? $policy_page : home_url('/customer-policies/')); ?>">Customer policies</a></p>
      </section>
    </div>
    <?php return ob_get_clean();
}
add_shortcode('budly_sales_agent', 'budly_sales_shortcode');

function budly_sales_policies_shortcode() {
    ob_start(); ?>
    <div class="budly-policies">
      <p><strong>Last approved:</strong> July 17, 2026</p>
      <h2>CBD, body-care, and cooking products</h2><p>These consumable and personal-care products are final sale. Damaged and incorrect orders are handled under the exception below.</p>
      <h2>Damaged or incorrect orders</h2><p>Email <a href="mailto:budlysupport@gmail.com">budlysupport@gmail.com</a> within 7 days of delivery. Include your order number and photos of the item and packaging. Replacement and refund requests are reviewed individually.</p>
      <h2>Physical books</h2><p>Physical books may be returned within 14 days if unused and in their original condition. Customers pay return shipping unless the order was damaged or incorrect.</p>
      <h2>Digital products</h2><p>Digital products and downloaded books are final sale after delivery or download.</p>
      <h2>Courses</h2><p>A refund may be requested before course access is delivered. Courses are final sale after access, materials, or participation begins.</p>
      <h2>Subscriptions</h2><p>Subscriptions renew monthly until canceled. Cancel through your customer account profile before the next renewal. If profile cancellation is unavailable or unsuccessful, email support. Orders already processed are not automatically refundable.</p>
      <h2>Shipping</h2><p>Rates and available destinations appear at checkout. Delivery dates are estimates and are not guaranteed. Orders that cannot be fulfilled to the selected destination will be refunded.</p>
      <h2>NFT memberships</h2><p>Membership begins when the transaction finishes processing. You may cancel within 7 days for a full refund if the membership has not been used. Using a membership discount counts as use and disqualifies the purchase from a refund. No financial return, resale value, or appreciation is promised.</p>
      <h2>Wholesale</h2><p>Website-supported prices, minimums, shipping, labeling, and commercial terms may be completed online. Requests outside the website’s available options may require support assistance.</p>
      <h2>Support</h2><p>Email <a href="mailto:budlysupport@gmail.com">budlysupport@gmail.com</a>. We normally respond within 3 business days.</p>
    </div>
    <?php return ob_get_clean();
}
add_shortcode('budly_sales_policies', 'budly_sales_policies_shortcode');

function budly_sales_handoff() {
    check_ajax_referer('budly_sales_handoff', 'nonce');
    $ip_key = 'budly_rate_' . md5(isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown');
    $attempts = (int) get_transient($ip_key);
    if ($attempts >= 5) {
        wp_send_json_error(array('message' => 'Please email budlysupport@gmail.com for assistance.'), 429);
    }
    set_transient($ip_key, $attempts + 1, HOUR_IN_SECONDS);
    $name = sanitize_text_field(isset($_POST['name']) ? wp_unslash($_POST['name']) : '');
    $email = sanitize_email(isset($_POST['email']) ? wp_unslash($_POST['email']) : '');
    $journey = sanitize_text_field(isset($_POST['journey']) ? wp_unslash($_POST['journey']) : '');
    $summary = sanitize_textarea_field(isset($_POST['summary']) ? wp_unslash($_POST['summary']) : '');
    if (!$name || !is_email($email) || !$summary) {
        wp_send_json_error(array('message' => 'Please provide a valid name, email, and request.'), 400);
    }
    $reference = strtoupper(wp_generate_password(8, false, false));
    $subject = 'Budly sales handoff ' . $reference . ' — ' . $journey;
    $body = "Reference: {$reference}\nName: {$name}\nEmail: {$email}\nJourney: {$journey}\n\nCustomer request:\n{$summary}";
    $headers = array('Reply-To: ' . $name . ' <' . $email . '>');
    $sent = wp_mail('budlysupport@gmail.com', $subject, $body, $headers);
    wp_send_json_success(array(
        'reference' => $reference,
        'sent' => (bool) $sent,
        'message' => $sent ? 'Your request was sent to Budly Support.' : 'Your reference was created. Please email Budly Support directly.',
    ));
}
add_action('wp_ajax_budly_sales_handoff', 'budly_sales_handoff');
add_action('wp_ajax_nopriv_budly_sales_handoff', 'budly_sales_handoff');
