<?php
namespace Budly\SecureMemory\Admin;
use Budly\SecureMemory\Config;
if(!defined('ABSPATH')){exit;}
final class AdminRepository{
 private $wpdb;public function __construct($database=null){if($database!==null){$this->wpdb=$database;return;}global $wpdb;$this->wpdb=$wpdb;}
 public function count($table,$where='1=1'){if(!in_array($table,array('customers','verification_requests','sessions','consent','conversation_memory','audit'),true))throw new \InvalidArgumentException('Unsupported metric table.');$allowed=array('1=1','status = \'active\'','status = \'revoked\'','delivery_status = \'failed\'','deleted_at IS NULL');if(!in_array($where,$allowed,true))throw new \InvalidArgumentException('Unsupported metric filter.');return(int)$this->wpdb->get_var('SELECT COUNT(*) FROM '.Config::table($table).' WHERE '.$where);}
 public function session_customer($session_id){return $this->wpdb->get_var($this->wpdb->prepare('SELECT customer_id FROM '.Config::table('sessions').' WHERE session_id=%s LIMIT 1',$session_id));}
 public function customer_internal_id($public_id){return $this->wpdb->get_var($this->wpdb->prepare('SELECT id FROM '.Config::table('customers').' WHERE public_id=%s LIMIT 1',$public_id));}
 public function audit(array $filters,$page,$per_page){$where=array('1=1');$args=array();foreach(array('event_type','severity','actor_type','result') as $key){if(!empty($filters[$key])){$where[]=$key.'=%s';$args[]=$key==='event_type'?substr(preg_replace('/[^a-z0-9._-]/','',strtolower((string)$filters[$key])),0,80):sanitize_key($filters[$key]);}}if(!empty($filters['date_from'])){$where[]='created_at >= %s';$args[]=sanitize_text_field($filters['date_from']).' 00:00:00';}if(!empty($filters['date_to'])){$where[]='created_at <= %s';$args[]=sanitize_text_field($filters['date_to']).' 23:59:59';}$offset=($page-1)*$per_page;$args[]=$per_page;$args[]=$offset;$sql='SELECT audit_id,event_type,actor_type,actor_id,customer_reference,conversation_id,result,severity,metadata_json,created_at FROM '.Config::table('audit').' WHERE '.implode(' AND ',$where).' ORDER BY created_at DESC LIMIT %d OFFSET %d';return $this->wpdb->get_results($this->wpdb->prepare($sql,$args),ARRAY_A);}
}
